const urls = [
  'https://www.pornhub.com/view_video.php?viewkey=ph58c0e7b970740',
];

module.exports = urls;
